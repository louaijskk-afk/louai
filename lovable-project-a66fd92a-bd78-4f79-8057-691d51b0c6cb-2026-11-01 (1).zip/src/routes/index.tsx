import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Louai Daoud — Entrepreneur algérien" },
      { name: "description", content: "Louai Daoud, entrepreneur algérien de 18 ans : business, marketing, stratégie." },
      { property: "og:title", content: "Louai Daoud — Entrepreneur algérien" },
      { property: "og:description", content: "Business, marketing, stratégie. Consultation gratuite sur WhatsApp." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return <iframe src="/site.html" title="Louai Daoud" className="fixed inset-0 h-full w-full border-0" />;
}
